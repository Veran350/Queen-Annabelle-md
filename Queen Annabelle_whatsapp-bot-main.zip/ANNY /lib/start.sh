while true
do
echo "Starting Queen Annabelle!"
node .
done